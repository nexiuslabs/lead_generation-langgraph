# Make src a package for reliable absolute imports (e.g., src.settings)
