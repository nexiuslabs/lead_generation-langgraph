from __future__ import annotations
from typing import TypedDict, List, Dict, Any
import os, asyncio, logging, inspect
from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

# ---------- logging ----------
logger = logging.getLogger("presdr")
_level = os.getenv("LOG_LEVEL","INFO").upper()
if not logger.handlers:
    h = logging.StreamHandler()
    fmt = logging.Formatter("[%(levelname)s] %(asctime)s %(name)s :: %(message)s", "%H:%M:%S")
    h.setFormatter(fmt)
    logger.addHandler(h)
logger.setLevel(_level)

class PreSDRState(TypedDict, total=False):
    messages: List[BaseMessage]
    icp: Dict[str, Any]
    candidates: List[Dict[str, Any]]
    results: List[Dict[str, Any]]

def _last_text(msgs) -> str:
    if not msgs:
        return ""
    m = msgs[-1]
    if isinstance(m, BaseMessage):
        return (m.content or "")
    if isinstance(m, dict):
        return (m.get("content") or "")
    return str(m)

def _log_state(prefix: str, state: Dict[str, Any]):
    prev = _last_text(state.get("messages"))
    logger.info("%s last='%s' keys=%s", prefix, prev[:120], list(state.keys()))

def log_node(name: str):
    def deco(fn):
        if inspect.iscoroutinefunction(fn):
            async def aw(state, *a, **kw):
                _log_state(f"▶ {name}", state)
                out = await fn(state, *a, **kw)
                logger.info("✔ %s → keys=%s", name, list(out.keys()))
                return out
            return aw
        else:
            def sw(state, *a, **kw):
                _log_state(f"▶ {name}", state)
                out = fn(state, *a, **kw)
                logger.info("✔ %s → keys=%s", name, list(out.keys()))
                return out
            return sw
    return deco

def _last_is_ai(messages) -> bool:
    if not messages:
        return False
    m = messages[-1]
    if isinstance(m, BaseMessage):
        return isinstance(m, AIMessage)
    if isinstance(m, dict):
        role = (m.get("type") or m.get("role") or "").lower()
        return role in ("ai", "assistant")
    return False

@log_node("icp")
def icp_discovery(state: PreSDRState) -> PreSDRState:
    icp = state.get("icp") or {}
    state["icp"] = icp
    text = _last_text(state.get("messages")).lower()

    if "industry" not in icp:
        state["messages"].append(AIMessage("Which industries or problem spaces? (e.g., SaaS, Pro Services)"))
        icp["industry"] = True
        return state
    if "employees" not in icp:
        state["messages"].append(AIMessage("Typical company size? (e.g., 10–200 employees)"))
        icp["employees"] = True
        return state
    if "geo" not in icp:
        state["messages"].append(AIMessage("Primary geographies? (SG, SEA, global)"))
        icp["geo"] = True
        return state
    if "signals" not in icp:
        state["messages"].append(AIMessage("Buying signals? (hiring, stack, certifications)"))
        icp["signals"] = True
        return state

    state["messages"].append(AIMessage("Great. Reply **confirm** to save, or tell me what to change."))
    return state

@log_node("confirm")
def icp_confirm(state: PreSDRState) -> PreSDRState:
    state["messages"].append(AIMessage("✅ ICP saved. Paste companies (comma-separated), or type **run enrichment**."))
    return state

@log_node("candidates")
def parse_candidates(state: PreSDRState) -> PreSDRState:
    last = _last_text(state.get("messages"))
    names = [n.strip() for n in last.split(",") if 1 < len(n.strip()) < 120]
    if names:
        state["candidates"] = [{"name": n} for n in names]
        state["messages"].append(AIMessage(f"Got {len(names)} companies. Type **run enrichment** to start."))
    else:
        state["messages"].append(AIMessage("Please paste a few company names (comma-separated)."))
    return state

@log_node("enrich")
async def run_enrichment(state: PreSDRState) -> PreSDRState:
    # PLACEHOLDER: you still call your enrichment + Odoo writes here.
    await asyncio.sleep(0.01)
    cands = state.get("candidates") or []
    state["results"] = [{"name": c["name"], "score": 0.7} for c in cands]
    state["messages"].append(AIMessage(f"Enrichment complete for {len(cands)} companies."))
    return state

def route(state: PreSDRState) -> str:
    text = _last_text(state.get("messages")).lower()
    if "confirm" in text:
        dest = "confirm"
    elif "run enrichment" in text:
        dest = "enrich"
    elif "," in text or "auto" in text:
        dest = "candidates"
    else:
        dest = "icp"
    logger.info("↪ router -> %s", dest)
    return dest

def build_presdr_graph():
    g = StateGraph(PreSDRState)
    g.add_node("icp", icp_discovery)
    g.add_node("confirm", icp_confirm)
    g.add_node("candidates", parse_candidates)
    g.add_node("enrich", run_enrichment)

    g.set_entry_point("icp")

    # IMPORTANT: these keys must match what route() returns
    g.add_conditional_edges("icp", route, {
        "confirm": "confirm",
        "enrich": "enrich",
        "candidates": "candidates",
        "icp": "icp",
    })
    g.add_conditional_edges("confirm", route, {
        "enrich": "enrich",
        "candidates": "candidates",
        "icp": "icp",
    })
    g.add_conditional_edges("candidates", route, {
        "enrich": "enrich",
        "icp": "icp",
    })
    g.add_edge("enrich", END)
    return g.compile()
