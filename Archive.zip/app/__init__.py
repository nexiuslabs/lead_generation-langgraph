# Make app a package for reliable imports (uvicorn app.main:app)
